enum ClockText{
  roman,
  arabic
}